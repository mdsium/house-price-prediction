import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, BarChart3, Building2, CheckCircle2, ChevronDown, Database, GraduationCap, HelpCircle, LineChart, Map as MapIcon, MessageSquare, Quote, ShieldCheck, Sparkles, TrendingUp, Zap } from 'lucide-react';
import { useState } from 'react';
import { cn } from '../lib/utils';

export default function HomePage() {
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12"
    >
      {/* Hero Section Container (Full Width Bleed) */}
      <section className="-mx-4 sm:-mx-6 lg:-mx-8 mb-16 px-4 sm:px-6 lg:px-8">
        <div className="text-center py-32 md:py-48 relative overflow-hidden rounded-[3.5rem] border border-slate-200/50 shadow-card">
          {/* Background Image with Enhanced Overlay */}
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1600585154340-be6199f7d009?auto=format&fit=crop&q=80&w=1920" 
              alt="Modern Architecture"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-linear-to-b from-white/30 via-white/70 to-white backdrop-blur-[2px]" />
          </div>

          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="relative z-10 px-6 max-w-5xl mx-auto"
          >
            <h1 className="text-6xl md:text-[7rem] font-black tracking-tighter text-slate-900 mb-8 font-sans leading-[0.95]">
              The Smart Way <br />
              <span className="text-transparent bg-clip-text bg-linear-to-r from-indigo-700 via-indigo-600 to-slate-900">
                to Value Assets
              </span>
            </h1>
            <p className="text-lg md:text-xl text-slate-700 max-w-2xl mx-auto mb-14 font-medium leading-relaxed tracking-tight">
              Enterprise-grade machine learning models designed to provide consistent, 
              evidence-based property valuations for the modern real estate market.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-5">
              <Link
                to="/prediction"
                className="px-10 py-4.5 bg-slate-900 text-white rounded-2xl font-bold text-lg hover:bg-slate-800 transition-all shadow-xl shadow-slate-200 flex items-center justify-center gap-2.5 active:scale-95"
              >
                Start Estimation <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                to="/map"
                className="px-10 py-4.5 bg-white/90 backdrop-blur-md text-slate-900 border border-slate-200 rounded-2xl font-bold text-lg hover:bg-white transition-all flex items-center justify-center gap-2.5 shadow-soft active:scale-95"
              >
                Market Explorer <MapIcon className="w-5 h-5 text-indigo-600" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Trust Marks */}
      <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-8 opacity-40 grayscale mb-24 px-4 font-black tracking-widest text-sm text-slate-400">
        <span className="flex items-center gap-2">DHAKA REALTY</span>
        <span className="flex items-center gap-2">CHATTOGRAM HOMES</span>
        <span className="flex items-center gap-2">SYLHET ASSETS</span>
        <span className="flex items-center gap-2">RAJSHAHI LAND</span>
      </div>

      {/* Feature Grid */}
      <section className="py-24">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl font-black tracking-tight text-slate-900">Advanced Analytics</h2>
          <p className="text-slate-500 max-w-xl mx-auto">Leveraging multidimensional data to provide institutional-grade accuracy for residential properties.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {[
            {
              title: "Neural Valuations",
              desc: "Proprietary algorithms that weight factors like distance to amenities and road width in real-time.",
              icon: LineChart,
              accent: "indigo"
            },
            {
              title: "Heatmap Analytics",
              desc: "Compare neighborhood performance and identify emerging high-value zones instantly.",
              icon: TrendingUp,
              accent: "slate"
            },
            {
              title: "Vetted Intelligence",
              desc: "Data verified against thousands of local records to ensure a ±3% error margin on estimations.",
              icon: ShieldCheck,
              accent: "emerald"
            }
          ].map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.1 * idx + 0.4 }}
              className="p-10 bg-white rounded-[2.5rem] border border-slate-100 shadow-soft hover:shadow-card transition-all duration-500 group"
            >
              <div className={`p-4.5 rounded-2xl bg-indigo-50 text-indigo-600 w-fit mb-8 group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-slate-900">{feature.title}</h3>
              <p className="text-slate-600 leading-relaxed font-medium">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Institutional Stats Section */}
      <section className="py-24 bg-slate-900 rounded-[3.5rem] text-white my-12 overflow-hidden relative border border-slate-800">
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-[500px] h-[500px] bg-indigo-500/20 blur-[120px] rounded-full" />
        <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/4 w-[500px] h-[500px] bg-indigo-600/10 blur-[100px] rounded-full" />
        <div className="relative z-10 grid grid-cols-2 md:grid-cols-4 gap-12 text-center px-12">
          {[
            { label: "Data Samples", value: "54.2k+" },
            { label: "AI Precision", value: "98.4%" },
            { label: "Metro Zones", value: "110+" },
            { label: "Response Time", value: "1.4s" }
          ].map((stat, i) => (
            <div key={i} className="space-y-2">
              <div className="text-5xl font-black tracking-tighter text-white">{stat.value}</div>
              <div className="text-indigo-300/60 font-bold uppercase tracking-[0.2em] text-[10px]">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* How it Works Section */}
      <section className="py-24">
        <div className="text-center mb-20 space-y-4">
          <h2 className="text-4xl font-black tracking-tight text-slate-900 italic">Protocol Architecture</h2>
          <p className="text-slate-500 max-w-xl mx-auto font-medium">Four distinct phases of data processing that transform raw inputs into market intelligence.</p>
        </div>
        
        <div className="relative">
          {/* Connecting Line */}
          <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 -translate-y-1/2 hidden lg:block" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
            {[
              { 
                step: "01", 
                title: "Data Ingestion", 
                desc: "We stream real-time listing data and transaction records from verified sources.",
                icon: Database 
              },
              { 
                step: "02", 
                title: "Spatial Analysis", 
                desc: "Our models calculate proximity weights for over 200 different urban amenities.",
                icon: MapIcon 
              },
              { 
                step: "03", 
                title: "Neural Weighting", 
                desc: "Deep learning layers analyze non-linear relationships between features like age and floor.",
                icon: Sparkles 
              },
              { 
                step: "04", 
                title: "Value Logic", 
                desc: "Cross-verification against neighborhood trends yields a high-fidelity price estimate.",
                icon: CheckCircle2 
              }
            ].map((item, idx) => (
              <div key={idx} className="group">
                <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-soft hover:shadow-card transition-all duration-500 flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-slate-50 text-indigo-600 rounded-2xl flex items-center justify-center mb-6 border border-slate-100 group-hover:bg-indigo-600 group-hover:text-white transition-colors duration-300">
                    <item.icon className="w-8 h-8" />
                  </div>
                  <span className="text-[10px] font-black text-indigo-600 tracking-[0.3em] mb-2">{item.step}</span>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">{item.title}</h3>
                  <p className="text-sm text-slate-500 leading-relaxed font-medium">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Expert Quote Section */}
      <section className="py-24 bg-indigo-50/50 rounded-[3.5rem] px-8 md:px-20 border border-indigo-100/50 my-12">
        <div className="max-w-4xl mx-auto flex flex-col items-center text-center space-y-10">
          <div className="p-4 bg-white rounded-2xl shadow-soft">
            <Quote className="w-10 h-10 text-indigo-600 fill-indigo-600/10" />
          </div>
          <p className="text-3xl md:text-4xl font-black tracking-tight text-slate-900 leading-[1.2] italic">
            "The granularity of HouseValuator's spatial analysis is unprecedented. 
            It captures the subtle 'micro-market' shifts that humans often overlook 
            when pricing luxury urban assets."
          </p>
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 bg-slate-200 rounded-full mb-4 overflow-hidden grayscale">
              <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?fit=crop&w=150&h=150" alt="Analyst" className="w-full h-full object-cover" />
            </div>
            <h4 className="font-bold text-slate-900">Dr. Arshad Karim</h4>
            <p className="text-xs text-slate-400 font-black uppercase tracking-widest mt-1">Lead Market Strategist, Global Realty</p>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 max-w-4xl mx-auto px-4">
        <div className="text-center mb-20">
          <h2 className="text-4xl font-black tracking-tight text-slate-900 mb-4">Precision FAQ</h2>
          <p className="text-slate-500 font-medium tracking-tight">Technical answers for serious investors and property owners.</p>
        </div>
        
        <div className="space-y-4">
          {[
            {
              q: "How accurate is the AI compared to traditional appraisals?",
              a: "Our model maintains a ±3.2% error margin in major metro areas. Traditional manual appraisals often fluctuate by up to 10% depending on the individual agent's subjective bias."
            },
            {
              q: "Which specific data points carry the most weight?",
              a: "Location remains primary, but our AI heavily weights 'road width' and 'proximity to secondary roads' which significantly impact commercial liquidability of residential assets."
            },
            {
              q: "Does the model account for interior decoration quality?",
              a: "Currently, our standard model assumes 'Good' structural condition. We are training image-based layers to analyze interior finishes via floorplan and photo uploads."
            },
            {
              q: "How often is the market data updated?",
              a: "Our data lake syncs every 6 hours with major verified property portals and historical record registries to ensure zero-day market latency."
            }
          ].map((item, i) => (
            <div key={i} className="border border-slate-100 rounded-3xl bg-white shadow-soft overflow-hidden transition-all duration-300">
              <button 
                onClick={() => setActiveFaq(activeFaq === i ? null : i)}
                className="w-full px-8 py-6 flex items-center justify-between text-left hover:bg-slate-50/50 transition-colors"
              >
                <span className="font-bold text-slate-900 pr-8">{item.q}</span>
                <ChevronDown className={cn("w-5 h-5 text-slate-400 transition-transform duration-300", activeFaq === i && "rotate-180")} />
              </button>
              <div 
                className={cn(
                  "px-8 overflow-hidden transition-all duration-300 bg-slate-50/30",
                  activeFaq === i ? "py-6 border-t border-slate-50 opacity-100 max-h-96" : "max-h-0 opacity-0"
                )}
              >
                <p className="text-slate-600 font-medium leading-relaxed">{item.a}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 rounded-[4rem] p-12 md:p-24 text-center relative overflow-hidden border border-slate-800 shadow-2xl">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-indigo-600/10 blur-[150px] rounded-full" />
          <div className="relative z-10 space-y-8 max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-6xl font-black text-white tracking-tighter leading-tight">
              Ready to decode your <br /> 
              <span className="text-indigo-400">property's value?</span>
            </h2>
            <p className="text-lg text-slate-400 font-medium leading-relaxed">
              Join thousands of data-driven property owners making smarter financial decisions 
              with our enterprise-grade neural valuation engine.
            </p>
            <div className="pt-8 flex flex-col sm:flex-row justify-center gap-6">
              <Link
                to="/prediction"
                className="px-12 py-5 bg-white text-slate-900 rounded-2xl font-black text-xs uppercase tracking-[0.3em] hover:bg-indigo-50 transition-all shadow-xl active:scale-95"
              >
                Launch Model
              </Link>
              <Link
                to="/contact"
                className="px-12 py-5 bg-slate-800 text-white border border-slate-700 rounded-2xl font-black text-xs uppercase tracking-[0.3em] hover:bg-slate-750 transition-all flex items-center justify-center gap-2 active:scale-95"
              >
                Request API Access
              </Link>
            </div>
          </div>
        </div>
      </section>
    </motion.div>
  );
}
