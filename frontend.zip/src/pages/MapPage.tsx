import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapContainer, TileLayer, Marker, Popup, useMap, ZoomControl, Tooltip } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { CITY_THANA_MAP, SAMPLE_HOUSE_DATA } from '../constants';
import { cn } from '../lib/utils';
import { 
  Building2, 
  ChevronRight, 
  GraduationCap, 
  Hospital, 
  Info, 
  Map as MapIcon, 
  Search, 
  ShoppingCart, 
  Store, 
  X,
  Filter,
  Layers,
  MapPin
} from 'lucide-react';

// Custom Icons using Lucide and DivIcon
const createCustomIcon = (color: string, IconSVG: string) => {
  return L.divIcon({
    html: `<div style="background-color: ${color}; padding: 8px; border-radius: 12px; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
        ${IconSVG}
      </svg>
    </div>`,
    className: 'custom-leaflet-icon',
    iconSize: [36, 36],
    iconAnchor: [18, 18],
  });
};

const Icons = {
  property: createCustomIcon('#4338ca', '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>'),
  school: createCustomIcon('#8b5cf6', '<path d="M22 10v6M2 10l10-5 10 5-10 5L2 10z"></path><path d="M6 12v5c0 2 2 3 6 3s6-1 6-3v-5"></path>'),
  hospital: createCustomIcon('#ef4444', '<path d="M19 14c1.49 0 2.87.47 4 1.26V8c0-1.1-.9-2-2-2h-4V3c0-1.1-.9-2-2-2H9c-1.1 0-2 .9-2 2v3H3c-1.1 0-2 .9-2 2v13c0 1.1.9 2 2 2h4.5M16 11V7l-2-2h-4l-2 2v4M12 13v8M9 17h6"></path>'),
  market: createCustomIcon('#f59e0b', '<path d="M3 3h18v18H3zM12 8v8M8 12h8"></path><path d="M3 9h18M3 15h18"></path>')
};

// Realistic mock data
const INSTITUTIONS = {
  school: [
    "North South University",
    "BRAC University",
    "Independent University, BD",
    "Scholastica School",
    "Mastermind International",
    "Sunbeams School",
    "Aga Khan School",
    "AIUB",
    "IUBAT",
    "Daffodil University"
  ],
  hospital: [
    "United Hospital",
    "Evercare Hospital",
    "Square Hospital",
    "Labaid Specialized",
    "Apollo Diagnostics",
    "Ibn Sina Hospital"
  ],
  market: [
    "Bashundhara City",
    "Jamuna Future Park",
    "Gulshan DCC Market",
    "Banani Super Market",
    "Rajuk Trade Center",
    "Unimart"
  ]
};

// Mock POI Data Generator
const generatePOIs = (center: { lat: number, lng: number }, count: number, type: string) => {
  const names = INSTITUTIONS[type as keyof typeof INSTITUTIONS] || [];
  return Array.from({ length: Math.min(count, names.length) }).map((_, i) => ({
    id: `${type}-${i}`,
    type,
    name: names[i % names.length],
    lat: center.lat + (Math.random() - 0.5) * 0.015,
    lng: center.lng + (Math.random() - 0.5) * 0.015,
    details: `Premier ${type} facility serving the ${type === 'school' ? 'academic' : 'public'} sector.`
  }));
};

const cityCenters: Record<string, { lat: number, lng: number }> = {
  'Dhaka': { lat: 23.7771, lng: 90.4130 },
  'Chattogram': { lat: 22.3275, lng: 91.8123 },
  'Rajshahi': { lat: 24.3685, lng: 88.6111 },
  'Sylhet': { lat: 24.8949, lng: 91.8687 }
};

// View controller to smooth pan the map
function ChangeView({ center, zoom }: { center: [number, number], zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom, { animate: true, duration: 1 });
  }, [center, zoom, map]);
  return null;
}

export default function MapPage() {
  const [selectedCity, setSelectedCity] = useState('Dhaka');
  const [selectedThana, setSelectedThana] = useState('Gulshan-1');
  const [showSchools, setShowSchools] = useState(false);
  const [showHospitals, setShowHospitals] = useState(false);
  const [showMarkets, setShowMarkets] = useState(false);
  
  const [mapCenter, setMapCenter] = useState<[number, number]>([23.7771, 90.4130]);
  const [zoom, setZoom] = useState(13);

  // Filter properties based on city and thana
  const filteredHouses = SAMPLE_HOUSE_DATA.filter(h => h.city === selectedCity && h.thana === selectedThana);
  
  // Center map on the first house of selected thana if available, else city center
  useEffect(() => {
    if (filteredHouses.length > 0 && filteredHouses[0].lat && filteredHouses[0].lng) {
      setMapCenter([filteredHouses[0].lat, filteredHouses[0].lng]);
      setZoom(14);
    } else {
      const center = cityCenters[selectedCity] || cityCenters['Dhaka'];
      setMapCenter([center.lat, center.lng]);
      setZoom(13);
    }
  }, [selectedCity, selectedThana]);

  // Generate POIs for the current view
  const pois = [
    ...(showSchools ? generatePOIs({ lat: mapCenter[0], lng: mapCenter[1] }, 5, 'school') : []),
    ...(showHospitals ? generatePOIs({ lat: mapCenter[0], lng: mapCenter[1] }, 3, 'hospital') : []),
    ...(showMarkets ? generatePOIs({ lat: mapCenter[0], lng: mapCenter[1] }, 4, 'market') : []),
  ];

  const categories = [
    { id: 'schools', label: 'Schools & Uni', icon: GraduationCap, active: showSchools, setter: setShowSchools, color: 'text-violet-600', bg: 'bg-violet-50' },
    { id: 'hospitals', label: 'Hospitals', icon: Hospital, active: showHospitals, setter: setShowHospitals, color: 'text-red-600', bg: 'bg-red-50' },
    { id: 'markets', label: 'Markets', icon: Store, active: showMarkets, setter: setShowMarkets, color: 'text-amber-600', bg: 'bg-amber-50' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="h-[calc(100vh-64px)] flex flex-col lg:flex-row overflow-hidden bg-slate-50"
    >
      {/* Sidebar */}
      <aside className="w-full lg:w-96 bg-white border-r border-slate-200 overflow-y-auto z-20 flex flex-col shadow-xl">
        <div className="p-8 border-b border-slate-100 bg-white sticky top-0 z-30">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-slate-900 rounded-xl flex items-center justify-center shadow-soft">
              <MapIcon className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-black text-slate-900 tracking-tighter">Market Explorer</h1>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Real-time Asset Mapping</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Primary Market / City</label>
              <div className="relative">
                <select
                  value={selectedCity}
                  onChange={(e) => {
                    setSelectedCity(e.target.value);
                    setSelectedThana(CITY_THANA_MAP[e.target.value][0]);
                  }}
                  className="w-full pl-5 pr-10 py-4 rounded-2xl border border-slate-200 bg-slate-50/50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 transition-all outline-none font-bold text-slate-700 appearance-none text-sm cursor-pointer"
                >
                  {Object.keys(CITY_THANA_MAP).map(city => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
                <ChevronRight className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 rotate-90" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Sub-Market / Thana</label>
              <div className="flex flex-wrap gap-2">
                {CITY_THANA_MAP[selectedCity].map(thana => (
                  <button
                    key={thana}
                    onClick={() => setSelectedThana(thana)}
                    className={cn(
                      "px-4 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-wider transition-all border",
                      selectedThana === thana
                        ? "bg-slate-900 text-white border-slate-900 shadow-soft"
                        : "bg-white text-slate-500 border-slate-100 hover:border-slate-200 hover:bg-slate-50"
                    )}
                  >
                    {thana}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="p-8 flex-1 space-y-10">
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Infrastructural Layers</label>
              <Layers className="w-3 h-3 text-slate-300" />
            </div>
            <div className="grid grid-cols-1 gap-3">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => cat.setter(!cat.active)}
                  className={cn(
                    "flex items-center justify-between p-4 rounded-2xl border transition-all duration-300",
                    cat.active 
                      ? `${cat.bg} border-slate-100 shadow-soft translate-x-1` 
                      : "bg-white border-slate-100 opacity-60 hover:opacity-100"
                  )}
                >
                  <div className="flex items-center gap-4">
                    <div className={cn("p-2.5 rounded-xl transition-all", cat.active ? `${cat.bg} ${cat.color} scale-110 shadow-sm border border-white` : "bg-slate-50 text-slate-400")}>
                      <cat.icon className="w-5 h-5" />
                    </div>
                    <span className={cn("text-xs font-black uppercase tracking-tight transition-colors", cat.active ? "text-slate-900" : "text-slate-500")}>
                      {cat.label}
                    </span>
                  </div>
                  <div className={cn(
                    "w-5 h-5 rounded-full flex items-center justify-center transition-all",
                    cat.active ? "bg-indigo-600 shadow-soft" : "border-2 border-slate-100"
                  )}>
                    {cat.active && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="p-6 bg-slate-900 rounded-[2rem] border border-slate-800 shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
               <Info className="w-12 h-12 text-white" />
            </div>
            <div className="relative z-10 space-y-4">
              <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-widest flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse" />
                Spatial Intelligence
              </h4>
              <p className="text-xs text-white/70 leading-relaxed font-medium">
                Map overlays highlight commercial nodes that contribute to property liquidation speed and value retention.
              </p>
              <div className="pt-2">
                <div className="flex items-center gap-2 text-[10px] font-black text-indigo-300 uppercase tracking-widest opacity-60">
                   System v4.2 Stable
                </div>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Map Area */}
      <main className="flex-1 relative z-10 bg-slate-200">
        <MapContainer 
          center={mapCenter} 
          zoom={zoom} 
          scrollWheelZoom={true}
          zoomControl={false}
          className="w-full h-full"
        >
          <ChangeView center={mapCenter} zoom={zoom} />
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png"
          />
          <ZoomControl position="bottomright" />

          {/* Property Markers */}
          {filteredHouses.map((house, idx) => (
            <Marker 
              key={`house-${idx}`} 
              position={[house.lat!, house.lng!]}
              icon={Icons.property}
            >
              <Popup className="custom-popup">
                <div className="p-1 min-w-[220px]">
                  <div className="flex items-center gap-2.5 mb-3">
                    <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                      <Building2 className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-slate-900 leading-tight">{house.thana}</h4>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{house.city}</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-end border-b border-slate-100 pb-2">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Market Value</span>
                      <span className="text-lg font-black text-indigo-600 tracking-tighter">৳{(house.price / 10000000).toFixed(2)}Cr</span>
                    </div>
                    <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase tracking-widest">
                      <span>{house.area_sqft} SQFT</span>
                      <span>৳{(house.price / house.area_sqft).toFixed(0)} / FT</span>
                    </div>
                  </div>
                </div>
              </Popup>
            </Marker>
          ))}

          {/* POI Markers */}
          {pois.map((poi) => (
            <Marker 
              key={poi.id} 
              position={[poi.lat, poi.lng]}
              icon={poi.type === 'school' ? Icons.school : poi.type === 'hospital' ? Icons.hospital : Icons.market}
            >
              <Tooltip permanent direction="top" offset={[0, -20]} className="custom-tooltip">
                <span className="font-black text-[10px] uppercase tracking-tighter text-slate-900">{poi.name}</span>
              </Tooltip>
              <Popup>
                <div className="p-1">
                  <div className="flex items-center gap-2 mb-2">
                    {poi.type === 'school' ? <GraduationCap className="w-4 h-4 text-violet-600" /> : poi.type === 'hospital' ? <Hospital className="w-4 h-4 text-red-600" /> : <Store className="w-4 h-4 text-amber-600" />}
                    <span className="font-black text-slate-900 text-sm uppercase tracking-tight">{poi.name}</span>
                  </div>
                  <p className="text-xs text-slate-500 font-medium">{poi.details}</p>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>

        {/* Floating Controls */}
        <div className="absolute top-8 left-8 z-[1001] hidden lg:flex items-center gap-4">
          <div className="bg-white/90 backdrop-blur-xl px-6 py-4 rounded-[1.5rem] border border-slate-200/50 shadow-2xl flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Map Live Feed</span>
            </div>
            <div className="w-px h-4 bg-slate-200" />
            <div className="text-[10px] font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
               Showing {filteredHouses.length} Assets in {selectedThana}
            </div>
          </div>
        </div>
      </main>

      <style>{`
        .leaflet-container {
          background-color: #f1f5f9;
        }
        .custom-popup .leaflet-popup-content-wrapper {
          border-radius: 24px;
          padding: 8px;
          border: 1px solid #f1f5f9;
          box-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.15);
        }
        .custom-popup .leaflet-popup-tip {
          background: white;
        }
        .leaflet-div-icon {
          background: transparent;
          border: none;
        }
        .custom-tooltip {
          background: white !important;
          border: 1px solid #e2e8f0 !important;
          border-radius: 8px !important;
          padding: 4px 8px !important;
          box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1) !important;
        }
        .custom-tooltip:before {
          border-top-color: white !important;
        }
      `}</style>
    </motion.div>
  );
}
