import { motion } from 'motion/react';
import { BrainCircuit, Database, ShieldCheck, Zap, BarChart3, LineChart } from 'lucide-react';

export default function AboutPage() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-4xl mx-auto px-4 py-24"
    >
      <div className="text-center mb-20 space-y-4">
        <h1 className="text-5xl font-black text-slate-900 tracking-tight">The Forensic Engine</h1>
        <p className="text-xl text-slate-500 font-medium max-w-2xl mx-auto">We transform raw market volatility into structured pricing intelligence through high-fidelity AI models.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-24">
        <div className="p-10 bg-white rounded-[2.5rem] border border-slate-200/60 shadow-soft">
          <div className="p-3.5 bg-indigo-50 text-indigo-600 w-fit rounded-2xl mb-8">
            <BrainCircuit className="w-10 h-10" />
          </div>
          <h3 className="text-2xl font-bold mb-4 text-slate-900">Neural Interpretation</h3>
          <p className="text-slate-600 leading-relaxed font-medium">
            Unlike traditional linear models, our implementation of Gemini 3 Flash analyzes multi-factor dependencies, identifying how a specific floor level influences value based on city-specific demand.
          </p>
        </div>
        <div className="p-10 bg-white rounded-[2.5rem] border border-slate-200/60 shadow-soft">
          <div className="p-3.5 bg-indigo-50 text-indigo-600 w-fit rounded-2xl mb-8">
            <Database className="w-10 h-10" />
          </div>
          <h3 className="text-2xl font-bold mb-4 text-slate-900">Curated Datasets</h3>
          <p className="text-slate-600 leading-relaxed font-medium">
            Our private database aggregates records from verified transactions, urban development plans, and infrastructural road maps to ensure environmental context is factored into every price point.
          </p>
        </div>
      </div>

      <div className="space-y-16">
        <h2 className="text-3xl font-black text-slate-900 text-center tracking-tight">Valuation Pipeline</h2>
        <div className="relative">
          <div className="absolute left-8 top-4 bottom-4 w-[2px] bg-indigo-50 hidden md:block" />
          
          {[
            {
              step: "Ingestion & Scrubbing",
              desc: "Consolidating fragmented market listings into standardized vector representations.",
              icon: BarChart3
            },
            {
              step: "Attribute Weighting",
              desc: "Deep analysis of micro-amenities and their impact on liquidity and final sale value.",
              icon: Zap
            },
            {
              step: "Spatial Correlation",
              desc: "Correcting bias through geographic positioning relative to commercial hubs and traffic arteries.",
              icon: ShieldCheck
            },
            {
              step: "Model Consensus",
              desc: "Triple-pass AI verification to generate a final price with a logical audit trail.",
              icon: LineChart
            }
          ].map((item, idx) => (
            <div key={idx} className="relative pl-0 md:pl-24 mb-14 last:mb-0">
              <div className="absolute left-0 top-0 w-16 h-16 bg-white border border-slate-200 rounded-3xl hidden md:flex items-center justify-center -translate-x-1/2 shadow-soft ring-8 ring-slate-50">
                <item.icon className="w-7 h-7 text-indigo-600" />
              </div>
              <div className="bg-white p-8 rounded-[2rem] border border-slate-200/60 shadow-soft">
                <h4 className="font-bold text-xl mb-2 text-slate-900">{item.step}</h4>
                <p className="text-slate-600 font-medium leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
